var searchData=
[
  ['ocalc',['OCalc',['../pagerank_8c.html#aa39fe86cf6e3199d6ceba6d5298d2fcc',1,'pagerank.c']]],
  ['oicalc',['OiCalc',['../pagerank_8c.html#ab58e45d8d04905f684151e589208d4c6',1,'pagerank.c']]]
];
