/**

@mainpage EPL232 File Compare

@author Marios Pafitis

This program is comparing line by line between two files. The user has to import two files. You have to
use the command fcompare [options] file1.txt file2.txt. You can also choose between three options in 
order to change the output. 

The three choices are:

/nc :Ignore capitalization

/s :Return only the first and the last time of continuous different lines.

/ln :Number the lines

You can you any of the changes from above and the order doesn't affect the output of the program.

If there is a diference in line length between the two files the algorithm will stop the comparison
in the last line of the small file and will print the line diference between the two files.

I found this project very useful as I have mastered my skills in data reading from files in C.
During this project I faced a lot of challenges in small details, and taught me 
that a code, in order to work, has to be specific! Also, I have learned that I don't have to sleep
8 hours per day, 4 hours of sleep are more than enough, if you want to finish your project! :)

*/