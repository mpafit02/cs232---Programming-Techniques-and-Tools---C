var searchData=
[
  ['calcdistfor',['calcDistFor',['../sedcmp_8c.html#a17497f763b06c91e6adecb4ed4a5eb85',1,'sedcmp.c']]],
  ['calcdistrec',['calcDistRec',['../sedcmp_8c.html#a9c1019287e12b462fe7262c74b7edd79',1,'sedcmp.c']]]
];
