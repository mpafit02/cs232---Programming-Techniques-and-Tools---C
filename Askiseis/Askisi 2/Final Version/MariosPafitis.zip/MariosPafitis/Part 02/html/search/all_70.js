var searchData=
[
  ['pagerank_2ec',['pagerank.c',['../pagerank_8c.html',1,'']]],
  ['prcalc',['PrCalc',['../pagerank_8c.html#ada5da9eb6b29105d4ac34ae2fcbe1721',1,'pagerank.c']]]
];
