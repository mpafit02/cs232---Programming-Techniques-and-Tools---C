var searchData=
[
  ['pagerank_2ec',['pagerank.c',['../pagerank_8c.html',1,'']]]
];
