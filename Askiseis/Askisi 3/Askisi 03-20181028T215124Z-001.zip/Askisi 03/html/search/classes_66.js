var searchData=
[
  ['frontier_5fnode',['frontier_node',['../structfrontier__node.html',1,'']]]
];
