var searchData=
[
  ['dequeue',['deQueue',['../Queue_8c.html#acb7489808206fc221709df31833f2704',1,'deQueue(QUEUE *queue, TREE_NODE **retVal):&#160;Queue.c'],['../Queue_8h.html#a7e2b9cb5d5e8bd96160ed6d9facf5e32',1,'deQueue(QUEUE *, TREE_NODE **):&#160;Queue.c']]]
];
