var searchData=
[
  ['puzzle_2ec',['puzzle.c',['../puzzle_8c.html',1,'']]],
  ['puzzle_2eh',['puzzle.h',['../puzzle_8h.html',1,'']]]
];
