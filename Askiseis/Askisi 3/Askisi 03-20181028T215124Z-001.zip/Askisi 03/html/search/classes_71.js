var searchData=
[
  ['queue',['QUEUE',['../structQUEUE.html',1,'']]]
];
