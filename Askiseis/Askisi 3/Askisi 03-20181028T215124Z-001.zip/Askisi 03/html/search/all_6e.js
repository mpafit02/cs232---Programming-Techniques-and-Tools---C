var searchData=
[
  ['next',['next',['../structfrontier__node.html#add5ba9e88e589d9673b40748df5bdfb9',1,'frontier_node']]]
];
