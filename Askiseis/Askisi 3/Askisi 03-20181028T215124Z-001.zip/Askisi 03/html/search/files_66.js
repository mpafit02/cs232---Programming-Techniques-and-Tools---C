var searchData=
[
  ['frontier_5fnode_2eh',['Frontier_Node.h',['../Frontier__Node_8h.html',1,'']]]
];
