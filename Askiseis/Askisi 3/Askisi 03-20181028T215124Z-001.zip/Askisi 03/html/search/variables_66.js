var searchData=
[
  ['frontier_5fhead',['frontier_head',['../structQUEUE.html#a01f5abaf70543a81190ff78664647188',1,'QUEUE']]],
  ['frontier_5ftail',['frontier_tail',['../structQUEUE.html#a1ba83f2481bf00ad19be069618da09b8',1,'QUEUE']]]
];
