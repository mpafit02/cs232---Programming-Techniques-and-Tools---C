var searchData=
[
  ['epl232_20the_20n_2dpuzzle_20and_20the_20algorithms',['EPL232 The n-puzzle and the algorithms',['../index.html',1,'']]]
];
