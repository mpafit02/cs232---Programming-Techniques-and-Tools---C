var searchData=
[
  ['leaf',['leaf',['../structfrontier__node.html#a82170fd5da68bd67bfb5f0040ecb9de0',1,'frontier_node']]]
];
