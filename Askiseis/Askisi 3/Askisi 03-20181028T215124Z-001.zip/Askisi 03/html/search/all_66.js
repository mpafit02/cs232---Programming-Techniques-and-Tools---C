var searchData=
[
  ['findchilds',['findChilds',['../puzzle_8c.html#a3931548cfe684abd5f34cfb799e8b756',1,'findChilds(int N, TREE_NODE *treeNode):&#160;puzzle.c'],['../puzzle_8h.html#ad09a22ef66b39b8ec677a6b0938405fa',1,'findChilds(int N, TREE_NODE *):&#160;puzzle.c']]],
  ['finddistance',['findDistance',['../puzzle_8c.html#a73c33838401b0342232090c6775e3b8b',1,'findDistance(int N, TREE_NODE *treeNode):&#160;puzzle.c'],['../puzzle_8h.html#a2329aa8b7d075ea86885ecd9ddf2105b',1,'findDistance(int, TREE_NODE *):&#160;puzzle.c']]],
  ['frontier_5fhead',['frontier_head',['../structQUEUE.html#a01f5abaf70543a81190ff78664647188',1,'QUEUE']]],
  ['frontier_5fnode',['frontier_node',['../structfrontier__node.html',1,'frontier_node'],['../Frontier__Node_8h.html#a9bc70933bdcbde2d3db8c8c0a20576d7',1,'FRONTIER_NODE():&#160;Frontier_Node.h']]],
  ['frontier_5fnode_2eh',['Frontier_Node.h',['../Frontier__Node_8h.html',1,'']]],
  ['frontier_5ftail',['frontier_tail',['../structQUEUE.html#a1ba83f2481bf00ad19be069618da09b8',1,'QUEUE']]]
];
