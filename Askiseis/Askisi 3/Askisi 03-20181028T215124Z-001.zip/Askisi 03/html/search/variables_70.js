var searchData=
[
  ['parent',['parent',['../structtree__node.html#a23176b684464fd150c42bba84ac00818',1,'tree_node']]],
  ['path',['path',['../structtree__node.html#a86c3fdd76acb0fe0ae546743d99ca196',1,'tree_node']]],
  ['previous',['previous',['../structfrontier__node.html#a219bf99227fcc0825051f21abf65ad8f',1,'frontier_node']]],
  ['puzzle',['puzzle',['../structtree__node.html#a3362cd235c8b6d8472c9488fdbce2e20',1,'tree_node']]]
];
