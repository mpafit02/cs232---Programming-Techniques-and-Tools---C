var searchData=
[
  ['g',['g',['../structtree__node.html#a500ab7ab20c0e746a58c89b39b6d3e89',1,'tree_node']]]
];
