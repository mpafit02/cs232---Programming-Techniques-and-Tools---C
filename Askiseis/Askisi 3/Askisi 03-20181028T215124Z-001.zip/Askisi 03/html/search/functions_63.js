var searchData=
[
  ['checkifthesame',['checkIfTheSame',['../puzzle_8c.html#a19b3308b87082d85bd7b0c83ece49f7a',1,'checkIfTheSame(int N, TREE_NODE *treeNode, int **puzzle):&#160;puzzle.c'],['../puzzle_8h.html#a042dbd8beb8ec5648cad0667a4d3a7ad',1,'checkIfTheSame(int, TREE_NODE *, int **):&#160;puzzle.c']]],
  ['createpuzzle',['createPuzzle',['../puzzle_8c.html#a1ebf9d23b8d1ff1be6f892673b1461b0',1,'createPuzzle(int N, int **puzzle):&#160;puzzle.c'],['../puzzle_8h.html#a8786ae6906dd8ba2357c96849ce5f9f9',1,'createPuzzle(int, int **):&#160;puzzle.c']]]
];
