var searchData=
[
  ['children',['children',['../structtree__node.html#a7ba6bc00b432b43ebf7ca47d2e6573ca',1,'tree_node']]]
];
