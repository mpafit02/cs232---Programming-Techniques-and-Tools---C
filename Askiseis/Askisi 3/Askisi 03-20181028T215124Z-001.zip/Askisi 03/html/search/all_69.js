var searchData=
[
  ['initqueue',['initQueue',['../Queue_8c.html#a0736eb6f0292a6c793740b4116aa80fd',1,'initQueue(QUEUE **queue):&#160;Queue.c'],['../Queue_8h.html#aa4b6c23fa8f184d79a19e647a61715ac',1,'initQueue(QUEUE **):&#160;Queue.c']]],
  ['inittree',['initTree',['../Tree_8c.html#ac0caa85cac3364521d000d800fcf8606',1,'initTree(TREE **tree):&#160;Tree.c'],['../Tree_8h.html#a4f436198f07db146031d681762235791',1,'initTree(TREE **):&#160;Tree.c']]],
  ['insertastar',['insertAStar',['../Queue_8c.html#adde424ac429d80d5449c64c32ceb2db8',1,'insertAStar(QUEUE *queue, TREE_NODE *treeNode):&#160;Queue.c'],['../Queue_8h.html#a383bb1f9813140a657b85a3061c7a955',1,'insertAStar(QUEUE *, TREE_NODE *):&#160;Queue.c']]],
  ['insertsorted',['insertSorted',['../Queue_8c.html#a70550c89d944ceae1bfc750f28f6b6e3',1,'insertSorted(QUEUE *queue, TREE_NODE *treeNode):&#160;Queue.c'],['../Queue_8h.html#adb87c1ba50ccbbe9a990a556b83e1ae9',1,'insertSorted(QUEUE *, TREE_NODE *):&#160;Queue.c']]],
  ['issolved',['isSolved',['../puzzle_8c.html#a87fc7249b7793c2ea516b14a38ce096c',1,'isSolved(int N, int **puzzle):&#160;puzzle.c'],['../puzzle_8h.html#a28bdd0e051e50b6fcbc57a64aa5086d6',1,'isSolved(int, int **):&#160;puzzle.c']]]
];
