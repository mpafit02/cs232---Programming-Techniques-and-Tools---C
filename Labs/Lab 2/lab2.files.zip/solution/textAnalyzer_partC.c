#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define NUMWORDS 200
#define WORDSIZE 15

int main() {
	char inputFile[15];
	char outputFile[15];
	char sentence[512];
	FILE *infp, *outfp;
	int i, j, k, upletters=0, lowletters=0, whitespaces=0, digits=0, others=0, total=0;
	char words[NUMWORDS][WORDSIZE], temp[WORDSIZE];
	char s[] = " ,.\n\t";
	char *token;

	printf("Please enter the name of the input file.\n");
	printf("Filename: ");
	scanf("%s", inputFile);
	printf("Please enter the name of the output file.\n");
	printf("Filename: ");
	scanf("%s", outputFile);
	
	if( (infp = fopen(inputFile, "r")) == NULL) {
		printf("Unable to open input file.\n");
		exit(-1);
	}

	k = 0;
	while(fgets(sentence, sizeof(sentence), infp) != NULL) {
		// letter analysis
		for(i=0; i<strlen(sentence); i++) {
			if(sentence[i] >= 'a' && sentence[i] <= 'z')
				lowletters++;
			else if(sentence[i] >= 'A' && sentence[i] <= 'Z')
				upletters++;
			else if(sentence[i] == ' ')
				whitespaces++;
			else if(sentence[i] >= '0' && sentence[i] <= '9')
				digits++;
			else
				others++;
			total++;
		}
		// word analysis
		token = strtok(sentence, s);
		while(token != NULL) {
			//printf("--> %s\n", token);
			strcpy(words[k], token);
			token = strtok(NULL, s);
			k++;
		}

	}

	// sort words
	for(i=k; i>0; i--)
		for(j=0; j<i-1; j++)
			if(strcmp(words[j], words[j+1]) > 0) {
				strcpy(temp, words[j]);
				strcpy(words[j], words[j+1]);
				strcpy(words[j+1], temp);
			}

	if( (outfp = fopen(outputFile, "w")) == NULL) {
		printf("Unable to open output file.\n");
		exit(-1);
	}

	fprintf(outfp, "Statistics for file: %s\n", inputFile);
	fprintf(outfp, "-------------------------------------------------\n\n");
	fprintf(outfp, "Total # of characters in file:\t%d\n\n", total);
	fprintf(outfp, "Letters\t\t\t%3d\t\t%5.2f \%\n", upletters+lowletters, 100.0*(upletters+lowletters)/total);
	fprintf(outfp, "White space\t\t%3d\t\t%5.2f \%\n", whitespaces, 100.0*whitespaces/total);
	fprintf(outfp, "Digits\t\t\t%3d\t\t%5.2f \%\n", digits, 100.0*digits/total);
	fprintf(outfp, "Other characters\t%3d\t\t%5.2f \%\n\n", others, 100.0*others/total);
	fprintf(outfp, "Total # of words in file:\t%d\n\n", k);
	fprintf(outfp, "The words of %s in alphabetical order:\n", inputFile);
	for(j=0; j<k; j++)
		fprintf(outfp, "%s\n", words[j]);
	
	printf("Processing complete.\n");
	return 0;
}
