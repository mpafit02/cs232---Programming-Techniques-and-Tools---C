#include <stdio.h>
#include <stdlib.h>

void readNumbers(int table[]);
int largestNumber(int table[]);
void printAll(int max, int table[]);

int main() {
	int table[20], max;	
	readNumbers(table);
	max = largestNumber(table);
	printAll(max,table);
}

void readNumbers(int table[]) {
	int i;
	FILE *fp;

	if( (fp = fopen("data.txt", "r")) == NULL) {
		printf("Cannot open file\n");
		exit(-1);
	}

	for(i=0; i<20; i++)
		fscanf(fp, "%d", &table[i]);

	fclose(fp);
}

int largestNumber(int table[]) {
	int i, max;

	max = table[0];
	for(i=1; i<20; i++)
		if(max < table[i])
			max = table[i];

	return max;
}

void printAll(int max, int table[]) {
	FILE *fp;
	int i;
	
	if( (fp = fopen("output.txt", "w")) == NULL) {
		printf("Cannot open file\n");
		exit(-1);
	}

	for(i=0; i<20; i++)
		fprintf(fp, "%d\n", table[i]);

	fprintf(fp, "The largest number in data.txt is %d.", max);
}
