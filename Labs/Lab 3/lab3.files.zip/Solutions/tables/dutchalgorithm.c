/** @file dutchalgorithm.c
 *  @brief Implementing the Dutch national flag problem
 *
 * The flag of the Netherlands consists of three colours: red, white and blue. 
 * Given balls of these three colours arranged randomly in a line (the actual 
 * number of balls does not matter), the task is to arrange them such that all
 * balls of the same colour are together and their collective colour groups are 
 * in the correct order.
 *
 * This problem can also be viewed in terms of rearranging elements of an array.
 * Suppose each of the possible elements could be classified into exactly one of
 * three categories (bottom, middle, and top). For example, if all elements are 
 * in 0 ... 1, the bottom could be defined as elements in 0 ... 0.1 (not 
 * including 0.1), the middle as 0.1 ... 0.3 (not including 0.3) and the top as 
 * 0.3 and greater. (The choice of these values illustrates that the categories 
 * need not be equal ranges).
 * The problem is then to produce an array such that all "bottom" elements come 
 * before (have an index less than the index of) all "middle" elements, which 
 * come before all "top" elements. And to do this sorting without later moving 
 * any element after placing it in the array.
 *
 * @author Pyrros Bratskas
 * @bug No known bugs.
 */ 


#include <stdio.h>
#include <stdlib.h>

#define MAX_ARRAY_LENGTH 20

void readElements(int [], int);
void printElements(int[], int);
void threeWayPartition(int [], int, int, int);
void swap(int *p, int *q);


/** @brief Read elements of a table from standard input
 *
 * @param table The table
 * @param size The table size
 * @return void 
 */
void readElements(int table[], int size) {
  int *p1;

  for(p1 = table; p1 < table + size; p1++) {
    printf("Give element %d: ", p1 - table);
    scanf("%d", p1);
  }
}


/** @brief Print elements of a table on standard output
 *
 * @param table The table
 * @param size The table size
 * @return void 
 */
void printElements(int table[], int size) {
  int *p1;
  
  for(p1 = table; p1 < table + size; p1++)
    printf("%d ", *p1);
  printf("\n");
}


void threeWayPartition(int data[], int size, int low, int high) {
  int p = -1;
  int q = size;
  int i;
  for (i = 0; i < q;) {
    if (data[i] < low) {
      swap(&data[i], &data[++p]);
      ++i;
    } 
    else
      if (data[i] >= high) {
	swap(&data[i], &data[--q]);
      } 
      else {
	++i;
      }
  }
}

void swap(int *p, int *q) {
  int tmp;
  tmp = *p;
  *p = *q;
  *q = tmp;
}


int main() {

  int table[MAX_ARRAY_LENGTH];
  int size;
  int lowLimit, highLimit;

  do {
    printf("Give the table size: ");
    scanf("%d", &size);
  } while(size > MAX_ARRAY_LENGTH);

  printf("\nEnter low limit: ");
  scanf("%d", &lowLimit);

  printf("\nEnter high limit: ");
  scanf("%d", &highLimit);

  readElements(table, size);
  
  threeWayPartition(table, size, lowLimit, highLimit);
  
  printf("\nThe table sorted using the dutch flag algorithm:\n");
  printElements(table, size);

  return EXIT_SUCCESS;
}
