/** @file roman2arab.c
 *  @brief Converts a roman to its corresponding arab number
 *
 * This program ask the user to enter a number in roman format, 
 * then converts it in arab number.
 * Remember: To write a number in roman format use the characters: 
 * I V X L C D M, i.e. Superbowl XLVII means: the 47th Superbowl
 *
 * @author Pyrros Bratskas
 * @bug No known bugs.
 */ 


#include <stdio.h>
#include <string.h>


/** @brief Converts a roman to an arab number
 *
 * @param s The number given as a string
 * @return The arab number 
 */
int romain2Arabe(char * s) {

  char chiffreRomain[] = "IVXLCDM";
  int chiffreArabe[] = {1, 5, 10, 50, 100, 500, 1000};

  int nombreAbrabe=0, derMax=1;
  int i, j, l = strlen(s);

  for (i=l-1; i>=0; i--) {
    j = 0;
    while(s[i]!=chiffreRomain[j]&&j<7) j++;
    if (chiffreArabe[j]>=derMax) {
      nombreAbrabe += chiffreArabe[j];
      derMax = chiffreArabe[j];
    }
    else nombreAbrabe -= chiffreArabe[j];
  }
  return nombreAbrabe;
}


int main() {
  printf("Bonjour,\n");
  char romain[100];
  int arabe;
  printf("Give a number in roman digits (%s) : ", "IVXLCDM");
  scanf("%s", romain);
  arabe = romain2Arabe(romain);
  printf("The number in arab digits is: %d\n", arabe);
  printf("Au revoir.\n");

  return (0);
}
