/** @file reverseTable.c
 *  @brief Pointers and tables
 *
 * This program reads a table of integers and reverses its elements
 * using only pointer arithmetic.
 *
 * @author Pyrros Bratskas
 * @bug No known bugs.
 */ 


#include <stdio.h>
#include <stdlib.h>

#define MAX_ARRAY_LENGTH 20

void readElements(int [], int);
void inverseElements(int [], int);
void printElements(int[], int);


/** @brief Read elements of a table from standard input
 *
 * @param table The table
 * @param size The table size
 * @return void 
 */
void readElements(int table[], int size) {
  int *p1;

  for(p1 = table; p1 < table + size; p1++) {
    printf("Give element %d: ", p1 - table);
    scanf("%d", p1);
  }
}


/** @brief Inverses elements of a table 
 *
 * @param table The table
 * @param size The table size
 * @return void 
 */
void inverseElements(int table[], int size) {
  int *p1, *p2;
  int temp;

  for(p1 = table, p2 = table + (size - 1); p1 < p2; p1++, p2--) {
    temp = *p1;
    *p1 = *p2;
    *p2 = temp;
  }
}


/** @brief Print elements of a table on standard output
 *
 * @param table The table
 * @param size The table size
 * @return void 
 */
void printElements(int table[], int size) {
  int *p1;
  
  for(p1 = table; p1 < table + size; p1++)
    printf("%d\n", *p1);
  printf("\n");
}


int main() {

  int table[MAX_ARRAY_LENGTH];
  int size;

  do {
    printf("Give the table size: ");
    scanf("%d", &size);
  } while(size > MAX_ARRAY_LENGTH);

  readElements(table, size);
  inverseElements(table, size);
  printElements(table, size);

  return EXIT_SUCCESS;
}
