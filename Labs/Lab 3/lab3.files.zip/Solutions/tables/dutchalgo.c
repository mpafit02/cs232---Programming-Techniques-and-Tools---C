#include <stdio.h>

void printArray(int [], int);
void dutchAlgo(int[], int);

int main() {
	int table[] = {0,2,1,2,1,1,0,0,1,1,2,2,1,0,0,2,1,0,0,0};
	int size = sizeof(table)/sizeof(int);

	printArray(table, size);
	
	dutchAlgo(table, size);

	printArray(table, size);
		
	return 0;
}

void printArray(int table[], int size) {
	int i;

	for(i=0; i<size; i++)
                printf("%d\t", table[i]);
        printf("\n");
}

void dutchAlgo(int table[], int size) {
	int i, temp;
	int low = 0, high = size-1;

	while(table[low] == 0)
		low++;
	while(table[high] == 2)
		high--;

	i = low;
	while(i < high) {
		if(table[i] == 0) {
			temp = table[i];
			table[i] = table[low];
			table[low] = temp;	
			low++;
			i++;
		}
		else if(table[i] == 2) {
			temp = table[i];
                        table[i] = table[high];
                        table[high] = temp;
			high--;
		}
		else
			i++;			
	}
}
