/** @file mergeTables.c
 *  @brief Merge two tables in a third table
 *
 * This program merges two sorted tables in a third table.
 * The third table is sorted as elements are entered to it.
 *
 * @author Pyrros Bratskas
 * @bug No known bugs.
 */ 


#include <stdio.h>

int main() {
  
  int firstTab[50], secondTab[50], mergedTab[100];
  int N, M;
  int i, j, k; 
  
  
  printf("Dimension of firstTab (max.50) : ");
  scanf("%d", &N );
  printf("Give the elements of firstTab in increasing order :\n");
  for (i=0; i<N; i++) {
    printf("Element firstTab[%d] : ", i);
    scanf("%d", &firstTab[i]);
  }

  printf("Dimension of secondTab (max.50) : ");
  scanf("%d", &M );
  printf("Give the elements of secondTab in increasing order :\n");
  for (j=0; j<M; j++) {
    printf("Element secondTab[%d] : ", j);
    scanf("%d", &secondTab[j]);
  }
  
  printf("Table firstTab :\n");
  for (i=0; i<N; i++)
    printf("%d ", firstTab[i]);
  printf("\n");
  
  printf("Table secondTab :\n");
  for (j=0; j<M; j++)
    printf("%d ", secondTab[j]);
  printf("\n");
  
  
  i=0; j=0; k=0;
  while ((i<N) && (j<M))
    if(firstTab[i]<secondTab[j]) {
      mergedTab[k]=firstTab[i];
      k++;
      i++;
    }
    else {
      mergedTab[k]=secondTab[j];
      k++;
      j++;
    }
  
  while (i<N) {
    mergedTab[k]=firstTab[i];
    k++;
    i++;
  }
  
  while (j<M) {
    mergedTab[k]=secondTab[j];
    k++;
    j++;
  }
 
  
  printf("Table mergedTab :\n");
  for (k=0; k<N+M; k++)
    printf("%d ", mergedTab[k]);
  printf("\n");
  
  return 0;
}

