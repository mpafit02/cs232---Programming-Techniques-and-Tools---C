/** @file dutchFlag.c
 *  @brief Sort a table made of 0, 1 and 2s
 *
 * This program sorts a table who's elements are 0, 1 and 2, in ascending oder.
 *
 * @author Pyrros Bratskas
 * @bug No known bugs.
 */ 


#include <stdio.h>

#define SIZE 10

int main() {
  int table[SIZE];
  int lo = 0, mid = 0, hi = SIZE-1; 
  int i, temp;

  for (i = 0; i < SIZE; i++) {
    printf("Element table[%d] : ", i);
    scanf("%d", &table[i]);
  }

  printf("The initial table :\n");
  for (i = 0; i < SIZE; i++)
    printf("%d ", table[i]);
  printf("\n");

  //move lo to a position where value is not 0 
  while ( lo < SIZE && table[lo] ==0)
    lo++;
  //move hi to a position where value is not 2
  while(hi >=0 && table[hi] == 2)  
    hi--; 

  //set mid to lo  
  mid = lo;  
  while (mid <= hi){
    //swap with lo if mid points to 0  
    //swap with hi if mid points to 1  
    //increment mid if it points to 1  
    if ( table[mid] == 0) {  
      //swap(table[lo],table[mid]); 
      temp = table[lo];
      table[lo] = table[mid];
      table[mid] = temp;

      lo++;
      mid++;  
    }  
    else 
      if (table[mid] == 1)  
	mid++;  
      else  {  
	//swap(table[mid],table[hi]);  
	temp = table[mid];
	table[mid] = table[hi];
	table[hi] = temp;

	hi--;  
      }  
  } 

  printf("The dutch flag table :\n");
  for (i = 0; i < SIZE; i++)
    printf("%d ", table[i]);
  printf("\n");

  return 0;
}

