/** @file pointsCols.c
 *  @brief A program that finds point cols in a 2D table
 *
 * This program finds all points cols of a 2D table. A point col 
 * is a element which is the maximum of all elements in its row
 * and the minimum of all elements in its column.
 *
 * @author Pyrros Bratskas
 * @bug No known bugs.
 */ 


#include <stdio.h>

int main() {
 
  int A[50][50];  /* given matrix */
  int MAX[50][50];/* auxiliary matrix with max of lines   */
  int MIN[50][50];/* auxiliary matrix with minima of columns */
  int N, M;    /* matrix dimensions */
  int i, j;    
  int temp;    
  int C;       /* count of points-cols */

 
  printf("Number of lines   (max.50) : ");
  scanf("%d", &N );
  printf("Number of columns (max.50) : ");
  scanf("%d", &M );
  for (i=0; i<N; i++)
    for (j=0; j<M; j++)
      {
	printf("Element[%d][%d] : ",i,j);
	scanf("%d", &A[i][j]);
      }
 
  printf("The Matrix :\n");
  for (i=0; i<N; i++) {
    for (j=0; j<M; j++)
      printf("%7d", A[i][j]);
    printf("\n");
  }

  for (i=0; i<N; i++)     {
   
    temp=A[i][0];
    for (j=1; j<M; j++)
      if (A[i][j]>temp) temp=A[i][j];
   
    for (j=0; j<M; j++)
      if (A[i][j]==temp)  
	MAX[i][j]=1;   
      else
	MAX[i][j]=0;
  }
 
  for (j=0; j<M; j++) {
   
    temp=A[0][j];
    for (i=1; i<N; i++)
      if (A[i][j]<temp) temp=A[i][j];
   
    for (i=0; i<N; i++)
      if (A[i][j]==temp)  
	MIN[i][j]=1;   
      else
	MIN[i][j]=0;
  }
 
  /* Print the result */
 
  printf("Points - cols :\n");
  for (C=0, i=0; i<N; i++)
    for (j=0; j<M; j++)
      if (MAX[i][j]&&MIN[i][j]) {
	C++;
	printf("The element %d\t is a maximum "
	       "in the line %d\n"
	       "             \t and a minimum "
	       "in the column %d\n", A[i][j], i, j);
      }
  if (C==0)
    printf("The table do not have de points-cols.\n");

  return 0;
}

