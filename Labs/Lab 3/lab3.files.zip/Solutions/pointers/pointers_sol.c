/** @file pointers_sol.c
 *  @brief Pointers and tables
 *
 * This program reads a table of integers and calculates using a 
 * function tha number of positives, negatives and zero elements 
 * in the table. 
 *
 * @author Your name here
 * @bug No known bugs.
 */ 


#include <stdio.h>
#include <stdlib.h>

/* Macro declaration */
#define MAX_SIZE 10

/* The prototype of function counting() */
void counting(int array[], int s, int *a, int *b, int *c);

/* The definition of function counting() */
void counting(int pinakas[], int megethos, int *thetikoi, int *arnitikoi, int *mhden) {
  int i;
  *thetikoi = *arnitikoi = *mhden = 0;
  for(i = 0; i < megethos; i++)
    if(pinakas[i] == 0) 
      ++*mhden;
    else 
      if(pinakas[i] > 0) 
	++*thetikoi;
      else 
	++*arnitikoi;
}

int main() {
  /* Variable declaration */
  int size, num_pos, num_neg, num_zero, count;
  
  /* Table declaration */
  int table[MAX_SIZE];
  
  /* Read data */
  printf("Dose to megethos toy pinaka (metaksi 1 kai %d): ", MAX_SIZE); 
  scanf("%d", &size);
  
  /* Checking table size */
  if(size < 1 || size > MAX_SIZE)
    exit(-1);
  
  /* Read data, put them in the table: */
  printf("Tha dwseis %d akeraious arithmous, ena-ena tin fora\n",size);                
  for(count = 0; count < size; count++){
    printf("Dwse arithmo %d: ", count+1);
    scanf("%d", &table[count]);
  } 
  
  /* Print table */
  printf("\nEktyposi pinaka:\n");
  for(count=0;count<size;count++)
    printf("table[%d] = %d\n", count, table[count]);
  
  /* Call function counting() */
  counting(table, size, &num_pos, &num_neg, &num_zero);
  
  /* Print results */
  printf("\nO pinakas periexei %d thetikous(o) arithmous,\n", num_pos);
  printf("%d arnhtikous arithmous(o), kai %d arithmous(o) iso me mhden.\n", num_neg, num_zero);
  
  return(0);
} 

