/** @file fun_struct_sol.c
 *  @brief Exercise on structs
 *
 *  Working with structs in C
 *
 *  @author Teaching Assistant
 *  @bug 
 */


/* ensomatosi vivliothikwn */
#include <stdio.h>

/* Dilosi statherwn */
#define NUM_STUDENTS 5
#define NUM_EXAMS 3

/* Orismos toy synthetoy typou students. SIMPLIRWSTE ANALOGWS */

/* Epikefalides synartisewn. SIMPLIRWSTE ANALOGWS */

/* Orismoi synartisewn. SIMPLIRWSTE ANALOGWS */

int main() {
	/* Dilosi metavlitwn */
	int numstud;

	/* Dilosi metavlitwn typoy students. SIMPLIRWSTE ANALOGWS */

	/* Klisi synartisewn. SIMPLIRWSTE ANALOGWS */

	return(0);
}
